<h3>In cooperation with</h3>

<?= HTML::anchor("http://www.destatis.de/", HTML::image("https://histat.gesis.org/histat/assets/img/layout/logo-destatis.png", array("alt" => "destatis")), array(), "http") ?>
<br/>
<br/>

<h3>What others say about histat</h3>
               <br>
                &quot;A really good and important project.&quot;<br><br>
                Prof. Dr. Martin Schulze Wessel<br>
                Chairman des Verbandes der Historiker und Historikerinnen Deutschlands<br><br><br>


                &quot;An indispensable data-repository for German economic and social history.&quot;<br><br>
                Prof. Dr. Jörg Baten<br>
                General Secretary der International Economic History Association <br><br><br>


                &quot;It is most certainly not possible to make it more comfortable.&quot;<br><br>
                Dr. Oliver Volckart<br>
                London School of Economics<br><br><br>

                &quot;It's great that GESIS collects this data and provides it to researchers.&quot;<br><br>
                Robin Winkler<br>
                DPhil candidate in Economic History, Oxford University
            <br><br>
<h3>Further cooperating Partners</h3>
<br/>
<ul class="normal">
    <li>
        Prof. Dr. Volker Müller-Benedict<br/>
        Lehrstuhl für Methodenlehre<br/>
        Universität Flensburg
    </li>
    <li>
        Prof. Dr. Carsten Burhop<br/>
        Seminar für Wirtschafts- und Unternehmensgeschichte<br/>
        Universität zu Köln
    </li>
    <li>
        Prof. Dr. Claude Diebolt<br/>
        BETA/CNRS (UMR 7522)<br/>
        Université de Strasbourg

    </li>
</ul>
<br/>
<h3>Layout:</h3>
<?= HTML::anchor("http://metavor.de/", HTML::image("https://metavor.de/images/logo-trans.png", array("alt" => "http://metavor.de/")), array(), "http") ?>

<br/>
<h3>Technical Realization:</h3>
<?= HTML::anchor("http://data-quest.de/", HTML::image("https://www.data-quest.de/fileadmin/dq_homepage/assets/bilder/logo.png", array("alt" => "http://data-quest.de")), array(), "http") ?>
